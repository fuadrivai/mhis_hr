<?php

return [
    'authentication_key' => env("FIREBASE_CREDENTIALS")
];
