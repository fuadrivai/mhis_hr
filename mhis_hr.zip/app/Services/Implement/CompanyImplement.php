<?php

namespace App\Services\Implement;

use App\Services\CompanyService;

class CompanyImplement implements CompanyService
{
    function get($request) {}
    function show($id) {}
    function post($request) {}
    function put($id, $request) {}
    function delete($id) {}
}
