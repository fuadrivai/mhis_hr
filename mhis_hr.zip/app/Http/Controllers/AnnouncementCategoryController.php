<?php

namespace App\Http\Controllers;

use App\Models\AnnouncementCategory;
use Illuminate\Http\Request;

class AnnouncementCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\AnnouncementCategory  $announcementCategory
     * @return \Illuminate\Http\Response
     */
    public function show(AnnouncementCategory $announcementCategory)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\AnnouncementCategory  $announcementCategory
     * @return \Illuminate\Http\Response
     */
    public function edit(AnnouncementCategory $announcementCategory)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\AnnouncementCategory  $announcementCategory
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AnnouncementCategory $announcementCategory)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\AnnouncementCategory  $announcementCategory
     * @return \Illuminate\Http\Response
     */
    public function destroy(AnnouncementCategory $announcementCategory)
    {
        //
    }
}
