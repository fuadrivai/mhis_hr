<?php

use App\Http\Controllers\AttendanceController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\PinLocationController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['middleware' => 'prevent-back-history'], function () {
    Route::get('/login', [AuthController::class, 'index'])->middleware('guest')->name('login');
    Route::resource('attendance', AttendanceController::class);
    Route::post('/login', [AuthController::class, 'authenticate']);


    Route::group(['middleware' => 'auth'], function () {
        Route::post('/logout', [AuthController::class, 'logout']);
        Route::get('/', [HomeController::class, 'index']);

        Route::put('/user/reset', [UserController::class, 'resetPassword']);
        Route::resource('user', UserController::class);

        Route::resource('location', PinLocationController::class);

        Route::post('employee/import', [EmployeeController::class, 'import_excel']);
        Route::get('employee/filter', [EmployeeController::class, 'filterLocation']);
        Route::resource('employee', EmployeeController::class);
    });
});
