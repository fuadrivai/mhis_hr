<?php

namespace App\Services;

interface OrganizationService
{
    function get();
    function show($id);
    function post($request);
    function put($request);
    function delete($id);
}
