<?php

namespace App\Services\Implement;

use App\Services\GsheetLinkService;
use GuzzleHttp\Client;

class GsheetLinkImplement implements GsheetLinkService
{
    function getSchoolCalendar()
    {
        try {
            $url = "https://script.google.com";
            $client =  new Client([
                'base_uri' => $url
            ]);
            $method     = 'GET';
            $path = "/a/macros/mutiaraharapan.sch.id/s/AKfycby3GpZVOQ9QBzpZm9jg27JXTntGCj5p8JhUPUdCvqiqb6MmbmXjiOrsadkKEhLNWxJP/exec";
            $queryParam = "?level=Preschool,Primary,Secondary,dc";
            $response = $client->request(
                $method,
                $path . $queryParam,
                [
                    'headers'   => [
                        "Content-Type" => "application/json"
                    ]
                ]
            );
            return json_decode($response->getBody());
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), $th->getCode());
        }
    }
    function getNewsletter()
    {
        try {
            $url = "https://script.google.com";
            $client =  new Client([
                'base_uri' => $url
            ]);
            $method     = 'GET';
            $path = "/macros/s/AKfycby2pXoGdSuIRFbC1HZUGAV8NSJEwQcYIbuYEMnhdqo0bbmj9qMg3ZjWfJnQP5TdnyFp/exec";
            $queryParam = "?level=Preschool,Primary,Secondary,dc";
            $response = $client->request(
                $method,
                $path . $queryParam,
                [
                    'headers'   => [
                        "Content-Type" => "application/json"
                    ]
                ]
            );
            return json_decode($response->getBody());
        } catch (\Throwable $th) {
            return response()->json($th->getMessage(), $th->getCode());
        }
    }
    function getGeneralAnnouncement() {}
}
