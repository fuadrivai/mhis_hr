<?php

namespace App\Services\Implement;

use App\Services\LocationService;

class LocationImplement implements LocationService
{
    function get()
    {
    }
    function show($id)
    {
    }
    function post($request)
    {
    }
    function put($request)
    {
    }
    function delete($id)
    {
    }
}
